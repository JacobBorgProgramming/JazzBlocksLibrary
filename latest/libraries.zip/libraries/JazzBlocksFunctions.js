//JazzBlocksFunctions.js
//discourage selection with the "disableselect" function!
//After downloading JazzBlocks
//Import JazzBlocksFunctions via below code
//<script type="text/javascript" src="./JazzBlocks/JazzBlocksFunctions.js"></script>

//JazzBlock DisableSelect (start)
function disableselect(e) {
  return false
}

function reEnable() {
  return true
}

document.onselectstart = new Function ("return false")

if (window.sidebar) {
  document.onmousedown = disableselect
  document.onclick = reEnable
}
//(end)
